package util;

public interface F<A, B> {

	B f(A a);

}
